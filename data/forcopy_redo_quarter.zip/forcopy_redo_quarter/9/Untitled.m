P315 = imread('c.png');
P315_gray = rgb2gray(P315);
P315_binary = im2bw(P315_gray, 0.15); % this value (0.1) should be adapted; one should test for each image
imwrite(P315_binary, 'b.png');

% BW=imread('a.png');
% CC = bwconncomp(BW);
% numPixels = cellfun(@numel,CC.PixelIdxList);
% [small_ones,idx] = find(numPixels<50);
% 
% for n=1:numel(idx)
%     BW(CC.PixelIdxList{idx(n)}) = 0;
% end
% 
% BW=~BW;
% CC = bwconncomp(BW);
% numPixels = cellfun(@numel,CC.PixelIdxList);
% [small_ones,idx] = find(numPixels<50);
% 
% for n=1:numel(idx)
%     BW(CC.PixelIdxList{idx(n)}) = 0;
% end
%   
% BW=~BW;
% imshow(BW)
% imwrite(BW,'a.png');